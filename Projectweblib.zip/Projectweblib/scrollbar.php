<style>
    /* Customize the scrollbar */
    ::-webkit-scrollbar {
        width: 0px;
        /* Set the width of the scrollbar */
    }

    ::-webkit-scrollbar-track {
        background: rgb(255, 255, 255);
        /* Set the background color of the track */
    }

    ::-webkit-scrollbar-thumb {
        background: rgb(216, 218, 228);
        /* Set the color of the scrollbar */
    }

    ::-webkit-scrollbar-thumb:hover {
        background: rgb(248, 249, 252);
        /* Set the color of the scrollbar when hovering */
    }
</style>